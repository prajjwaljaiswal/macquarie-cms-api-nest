import { Controller } from '@nestjs/common';

@Controller('registrant')
export class RegistrantController {}
