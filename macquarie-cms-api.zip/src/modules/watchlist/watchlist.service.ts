import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { WatchListEntitity } from './watchlist.entitiy';


@Injectable()
export class WatchListService {
    constructor(
        @InjectRepository(WatchListEntitity)
        private readonly WatchListEntitity: Repository<WatchListEntitity>,
    ){}

    async getWatchlist(body){
        const { ric, symbol } = body;
        let query = "";
        if(ric){
            query = `Select s.ticker as symbol,type, exercise_price as strike,wrnt_per_share as ratio,last_trading_date from mqwarrants.warrants_screener as s LEFT JOIN mqwarrants.warrants_issuers as i on i.issuer_name = s.issuer_name JOIN mqwarrants.warrants_issued_date as j on j.ric = s.ric where s.ric = "${ric}";`
        }else {
            query = `select symbol, call_put as type, strike, ratio, IF(STRCMP(a.last_date,'0000-00-00'), a.last_date, NULL) as last_trading_date from mqwarrantscms.newly_listed a where symbol="${symbol}"` ;
        }

        return await this.WatchListEntitity.query(query) 
    }

}

